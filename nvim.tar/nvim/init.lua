local lsp_zero = require('lsp-zero')
lsp_zero.extend_lspconfig()
lsp_zero.on_attach(function(client, bufnr)
  lsp_zero.default_keymaps({buffer = bufnr})
end)
require("ember.remap")
require("ember.packer")
require("ember.harpoon")
require("ember.treesitter")
require("ember.color")
require("ember.lsp")
--regular vim stuff
vim.wo.relativenumber = true
vim.wo.number = true
local o = vim.o
o.expandtab = true
o.smarttab = true
o.smartindent = true
o.tabstop = 2
o.shiftwidth = 2
vim.opt.mouse = ""

