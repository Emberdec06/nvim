vim.g.mapleader = " "
vim.keymap.set("n", "<leader>pv", vim.cmd.Ex)
require'lspconfig'.lua_ls.setup{}
