local lsp_zero = require('lsp-zero')
require('mason').setup({pip = {upgrade_pip =true,}})
require('mason-lspconfig').setup({
	ensure_installed = {'csharp_ls'},
	handlers = {
		lsp_zero.default_setup,
	},
})


